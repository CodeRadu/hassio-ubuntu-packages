#! /usr/bin/bash

mkdir -p /etc/default
mkdir -p /etc/init.d
mkdir -p /etc/pam.d
mkdir -p /etc/runit/runsvdir/default
mkdir -p /etc/sv
mkdir -p /etc/ufw/applications.d

ln -s /etc/default/ssh /data/packages/ssh/etc/default/ssh
ln -s /etc/init.d/ssh /data/packages/ssh/etc/init.d/ssh
ln -s /etc/pam.d/sshd /data/packages/ssh/etc/pam.d/sshd
ln -s /etc/ssh /data/packages/ssh/etc/ssh
ln -s /etc/sv/ssh /data/packages/ssh/etc/sv/ssh
ln -s /etc/ufw/applications.d/openssh-server /data/packages/ssh/etc/ufw/applications.d/openssh-server

cp -r /data/packages/ssh/lib/* /lib
cp -r /data/packages/ssh/usr/* /usr
cp -r /data/packages/ssh/var/* /var