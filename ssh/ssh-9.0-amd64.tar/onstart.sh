#! /usr/bin/bash

mkdir -p /etc/default
mkdir -p /etc/init.d
mkdir -p /etc/pam.d
mkdir -p /etc/runit/runsvdir/default
mkdir -p /etc/sv
mkdir -p /etc/ufw/applications.d

ln -s /data/packages/ssh/etc/default/ssh /etc/default/ssh
ln -s /data/packages/ssh/etc/init.d/ssh /etc/init.d/ssh
ln -s /data/packages/ssh/etc/pam.d/sshd /etc/pam.d/sshd
ln -s /data/packages/ssh/etc/ssh /etc/ssh
ln -s /data/packages/ssh/etc/sv/ssh /etc/sv/ssh
ln -s /data/packages/ssh/etc/ufw/applications.d/openssh-server /etc/ufw/applications.d/openssh-server

cp -r /data/packages/ssh/lib/* /lib
cp -r /data/packages/ssh/usr/* /usr
cp -r /data/packages/ssh/var/* /var